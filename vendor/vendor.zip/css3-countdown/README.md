css3-countdown
==============

### Flip style countdown timer

You can easily create countdown page (teaser site, etc…).

# Demo

<http://sanographix.github.io/css3-countdown/demo/>


# Usage


## 1. Edit HTML

1. Edit h1, h2, and footer text.


## 2. Edit JavaScript

1. Set countdown limit (line:33)
2. (Optional) Add time's up message (line:36)



I created this countdown timer by using this script:  
[コピペでサクッと導入できるライブラリ非依存のJavascriptカウントダウン](http://plusblog.jp/3719/)



# Author

Showkaku Sano (sanographix)

* [website](http://www.sanographix.net/)
* [@sanographix](https://twitter.com/sanographix)
* [https://github.com/sanographix](https://github.com/sanographix)